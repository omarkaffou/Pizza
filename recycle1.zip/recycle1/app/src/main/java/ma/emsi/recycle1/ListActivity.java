package ma.emsi.recycle1;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import ma.emsi.recycle1.adapter.StarAdapter;
import ma.emsi.recycle1.beans.Star;
import ma.emsi.recycle1.service.StarService;

public class ListActivity extends AppCompatActivity {
    private List<Star> stars;
    private RecyclerView recyclerView;
    private StarAdapter starAdapter = null;
    StarService service = StarService.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_list);
        stars = new ArrayList<>();
        service = StarService.getInstance();
        init();
        recyclerView = findViewById(R.id.recycle_view);
        starAdapter = new StarAdapter(this, service.findAll());
        recyclerView.setAdapter(starAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    public void init() {
        service.create(new Star("kate bosworth", "https://media.gettyimages.com/photos/walk-of-fame-hollywood-star-tom-hanks-xxxl-picture-id458138841?s=2048x2048", 3.5f));
        service.create(new Star("george clooney", "https://media.gettyimages.com/photos/walk-of-fame-hollywood-star-tom-hanks-xxxl-picture-id458138841?s=2048x2048", 3));
        service.create(new Star("michelle rodriguez", "https://media.gettyimages.com/photos/walk-of-fame-hollywood-star-tom-hanks-xxxl-picture-id458138841?s=2048x2048", 5));
        service.create(new Star("george clooney", "https://media.gettyimages.com/photos/walk-of-fame-hollywood-star-tom-hanks-xxxl-picture-id458138841?s=2048x2048", 1));
        service.create(new Star("louise bouroin", "https://media.gettyimages.com/photos/walk-of-fame-hollywood-star-tom-hanks-xxxl-picture-id458138841?s=2048x2048", 5));
        service.create(new Star("louise bouroin", "https://media.gettyimages.com/photos/walk-of-fame-hollywood-star-tom-hanks-xxxl-picture-id458138841?s=2048x2048", 1));
    }
}